import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import './DressCode.css';

const DressCode = () => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1
  });

  return (
    <section className="dresscode-section" id="dresscode" ref={ref}>
      <div className="dresscode-container">
        <div className="dresscode-content">
          <motion.h2 
            className="dresscode-title branch-title"
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            Dress code
          </motion.h2>

          <div className="dresscode-details">
            {/* Women's Dress Code */}
            <motion.div 
              className="dress-section"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              <div className="dress-header">
                <h3 className="branch-title">Mujeres</h3>
                <p className="dress-subtitle satoshi-text">Vestido Largo</p>
              </div>
              <div className="dress-requirements">
                <p>Formal</p>
                <p>Unicolor</p>
                <p>Sin estampados</p>
                <p>Se reserva blanco y escala de beiges muy claros</p>
              </div>
            </motion.div>

            {/* Men's Dress Code */}
            <motion.div 
              className="dress-section"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.4, duration: 0.6 }}
            >
              <div className="dress-header">
                <h3 className="branch-title">Hombres</h3>
                <p className="dress-subtitle satoshi-text">Smoking</p>
              </div>
              <div className="dress-requirements">
                <p>Chaqueta Negra</p>
                <p>Pantalón Negro</p>
                <p>Camisa Blanca</p>
                <p>Zapato Formal Negro</p>
                <p>Corbatín Negro</p>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Side Image */}
        <motion.div 
          className="dresscode-image"
          initial={{ opacity: 0, x: 670, scale: 1.3, rotateY: 90 }}
          animate={inView ? { opacity: 1, x: 0, scale: 1, rotateY: 0 } : {}}
          transition={{ delay: 0.4, duration: 0.8, ease: [0.44, 0, 0.56, 1] }}
        >
          <img 
            src="https://framerusercontent.com/images/8SeMb1xq6mVs5akUAqNYXqqxO8.png?width=1440&height=1600" 
            alt="Dress code inspiration" 
          />
        </motion.div>
      </div>
    </section>
  );
};

export default DressCode;